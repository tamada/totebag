use std::io::{Read, Seek};
use std::{fs::File, path::PathBuf};

use crate::cli::{Result, ToatError};
use crate::extractor::{Extractor, ExtractorOpts};
use crate::format::Format;

pub(super) struct TarExtractor {
}
pub(super) struct TarGzExtractor {
}
pub(super) struct TarBz2Extractor {
}

impl Extractor for TarExtractor {
    fn list_archives(&self, archive_file: PathBuf) -> Result<Vec<String>> {
        let file = File::open(archive_file).unwrap();
        let mut archive = tar::Archive::new(file);
        list_tar(&mut archive)
    }
    fn perform(&self, archive_file: PathBuf, opts: &ExtractorOpts) -> Result<()> {
        Ok(())
    }
    fn format(&self) -> Format {
        Format::Tar
    }
}

fn list_tar<R: Read + Seek>(archive: &mut tar::Archive<R>) -> Result<Vec<String>> {
    let mut result = Vec::<String>::new();
    for entry in archive.entries().unwrap() {
        let entry = entry.unwrap();
        result.push(format!("{:?}", entry.header().path().unwrap()));
    }
    Ok(result)
}

impl Extractor for TarGzExtractor {
    fn list_archives(&self, archive_file: PathBuf) -> Result<Vec<String>> {
        Ok(vec![])
    }
    fn perform(&self, archive_file: PathBuf, opts: &ExtractorOpts) -> Result<()> {
        Ok(())
    }
    fn format(&self) -> Format {
        Format::TarGz
    }
}

impl Extractor for TarBz2Extractor {
    fn list_archives(&self, archive_file: PathBuf) -> Result<Vec<String>> {
        Ok(vec![])
    }
    fn perform(&self, archive_file: PathBuf, opts: &ExtractorOpts) -> Result<()> {
        Ok(())
    }
    fn format(&self) -> Format {
        Format::TarBz2
    }
}