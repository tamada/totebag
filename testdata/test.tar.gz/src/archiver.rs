use std::fs::File;
use std::path::PathBuf;

use crate::cli::{ToatError, Result};
use crate::format::{find_format, Format};
use crate::archiver::zip::ZipArchiver;
use crate::archiver::rar::RarArchiver;
use crate::archiver::tar::{TarArchiver, TarGzArchiver, TarBz2Archiver};

mod zip;
mod rar;
mod tar;

pub trait Archiver {
    fn perform(&self, inout: ArchiverOpts) -> Result<()>;
    fn format(&self) -> Format;
}

pub fn create_archiver(dest: PathBuf) -> Result<Box<dyn Archiver>> {
    let format = find_format(dest.file_name());
    match format {
        Ok(format) => {
            return match format {
                Format::Zip => Ok(Box::new(ZipArchiver{})),
                Format::Tar => Ok(Box::new(TarArchiver{})),
                Format::TarGz => Ok(Box::new(TarGzArchiver{})),
                Format::TarBz2 => Ok(Box::new(TarBz2Archiver{})),
                Format::Rar => Ok(Box::new(RarArchiver{})),
                _ => Err(ToatError::UnsupportedFormat("unsupported format".to_string())),
            }
        }
        Err(msg) => Err(msg),
    }
}

pub fn archiver_info(archiver: Box<dyn Archiver>, inout: ArchiverOpts) -> String {
    format!(
        "Format: {:?}\nDestination: {:?}\nTargets: {:?}",
        archiver.format(),
        inout.destination(),
        inout.targets().iter()
            .map(|item| item.to_str().unwrap())
            .collect::<Vec<_>>().join(", ")
    )
}

pub struct ArchiverOpts {
    pub dest: PathBuf,
    pub targets: Vec<PathBuf>,
    pub overwrite: bool,
    pub recursive: bool,
}

impl ArchiverOpts {
    pub fn new(dest: PathBuf, targets: Vec<PathBuf>, overwrite: bool, recursive: bool) -> Self {
        ArchiverOpts { dest, targets, overwrite, recursive }
    }
    pub fn targets(&self) -> Vec<PathBuf> {
        self.targets.clone()
    }
    pub fn destination(&self) -> Result<File> {
        let p = self.dest.as_path();
        if p.is_file() && p.exists() && !self.overwrite {
            return Err(ToatError::FileExists(self.dest.clone()))
        }
        match File::create(self.dest.as_path()) {
            Err(e) => Err(ToatError::IOError(e)),
            Ok(f) => Ok(f),
        }
    }
}
